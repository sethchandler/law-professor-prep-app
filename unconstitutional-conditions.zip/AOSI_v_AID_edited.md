# AGENCY FOR INTERNATIONAL DEVELOPMENT v. ALLIANCE FOR OPEN SOCIETY INTERNATIONAL, INC.
570 U.S. 205 (2013)

CHIEF JUSTICE ROBERTS delivered the opinion of the Court.

The United States Leadership Against HIV/AIDS, Tuberculosis, and Malaria Act of 2003 (Leadership Act) authorized the appropriation of billions of dollars to fund efforts by nongovernmental organizations to combat HIV/AIDS worldwide. The Act imposes two related conditions: (1) No funds "may be used to promote or advocate the legalization or practice of prostitution," and (2) no funds may be used by an organization "that does not have a policy explicitly opposing prostitution and sex trafficking." To enforce the second condition, known as the Policy Requirement, the Department of Health and Human Services (HHS) and the United States Agency for International Development (USAID) require funding recipients to agree in their award documents that they oppose prostitution and sex trafficking.

Respondents are domestic organizations engaged in combating HIV/AIDS overseas. Respondents fear that adopting a policy explicitly opposing prostitution may alienate certain host governments, diminish the effectiveness of their programs by making it more difficult to work with prostitutes in the fight against HIV/AIDS, and require them to censor privately funded discussions about how best to prevent the spread of HIV/AIDS among prostitutes.

In 2005, respondents commenced this litigation, seeking a declaratory judgment that the Policy Requirement violated their First Amendment rights. [The District Court granted a preliminary injunction, which the Second Circuit affirmed. We granted certiorari.]

## II

The Policy Requirement mandates that recipients of Leadership Act funds explicitly agree with the Government's policy to oppose prostitution and sex trafficking. It is, however, a basic First Amendment principle that "freedom of speech prohibits the government from telling people what they must say." ... "At the heart of the First Amendment lies the principle that each person should decide for himself or herself the ideas and beliefs deserving of expression, consideration, and adherence."

Were it enacted as a direct regulation of speech, the Policy Requirement would plainly violate the First Amendment. The question is whether the Government may nonetheless impose that requirement as a condition on the receipt of federal funds.

As a general matter, if a party objects to a condition on the receipt of federal funding, its recourse is to decline the funds. This remains true when the objection is that a condition may affect the recipient's speech. We have held that the Government "may not deny a benefit to a person on a basis that infringes his constitutionally protected ... freedom of speech even if he has no entitlement to that benefit."

Here, by requiring recipients to profess a specific belief, the Policy Requirement goes beyond defining the limits of the federally funded program to defining the recipient.

The Government contends that the affiliate guidelines it has promulgated, which allow a funding recipient to establish affiliates that may not profess its belief in opposition to prostitution, save the program. The Government suggests that because the recipient may channel its funding through an affiliate that adopts the required policy, while maintaining a separate affiliate that is free to abstain from such a pledge, the funding condition "permits funding recipients to 'limit their messages to those supported by the Government ... without forcing them to relinquish their right to communicate a different message when they are not speaking for the Government.'"

That argument assumes that the Policy Requirement is nothing more than a limitation on how federal funds may be used, a question we address below. Before we get there, however, it is important to note that the Affiliate Guidelines do not avail the Government of the argument they helped win in Rust v. Sullivan, 500 U.S. 173 (1991).

In Rust, a federal law provided family-planning grants to private entities, but prohibited use of funds for programs "where abortion is a method of family planning." ... Regulations implementing this funding condition prohibited funding recipients from engaging in certain forms of abortion-related activities outside the federally funded program, even with privately raised funds. ... In particular, the regulations barred the use of any Title X project facilities or personnel to provide abortion counseling and referral, or to engage in lobbying or advocacy activities in support of abortion.

We upheld these restrictions, reasoning that Congress had defined the federal program to exclude abortion advocacy, and that the doctors therefore could not use Title X project funds for that purpose. We explained that "[b]y requiring that the Title X grantee engage in abortion-related activity separately from activity receiving federal funding ... Congress has ... not denied [the grantee] the right to engage in abortion-related activities. Congress has merely refused to fund such activities." ...

The Title X regulations did not, we said, "force the Title X grantee to give up abortion-related speech; they merely require[d] that the grantee keep such activities separate and distinct from Title X activities." Title X grants were awarded to specific projects, and a recipient could establish a Title X project and "continue to perform abortions, provide abortion-related services, and engage in abortion advocacy; it simply [had to] conduct those activities through programs that [were] separate and independent from the project that receive[d] Title X funds." ... We observed that Title X "expressly distinguished between a Title X grantee and a Title X project": "The regulations governing Title X ... do not prohibit those organizations from creating ... facilities that are separate and independent from a Title X project's facilities."

As the Court of Appeals pointed out, however, "the distinction between the program and the recipient drawn in Rust does not exist in the Leadership Act context." ... Here the grant recipients are the organizations themselves. ... When recipients express a view on prostitution and sex trafficking, that expression goes to their own values.

The Policy Requirement compels as a condition of federal funding the affirmation of a belief that by its nature cannot be confined within the scope of the Government program. In so doing, it violates the First Amendment and cannot be sustained.
The difference between Rust and the present case is that in Rust, the program itself (specifically the Title X project) was defined as not permitting abortion activities. The regulations there prohibited Title X project employees from engaging in certain activities, but Title X grantees could establish parallel Title X projects and non-Title X projects. Here, the condition is imposed on the recipient itself - the organization. By demanding that funding recipients adopt-as their own-the Government's view on an issue of public concern, that condition by its very nature affects "protected conduct outside the scope of the federally funded program."

Unlike the Title X program regulations in Rust, the Policy Requirement in this case is not simply a program condition; instead, it requires recipients to profess a specific belief. Adopting that belief as the recipient's own policy effectively controls what the recipient can say outside the scope of the federal program. Having taken the required pledge, a recipient is no longer free to "turn around and assert a contrary belief, or claim neutrality, when participating in activities on its own time and dime."

The Government suggests that the Affiliate Guidelines provide an alternative avenue - a recipient could establish an affiliate to espouse antiprostitution beliefs required for funding, while maintaining a separate affiliate free from that requirement. But this arrangement fails.

If the affiliate is closely connected to the funding recipient, the affiliate arrangement does not significantly reduce the risk that the recipient's speech will be distorted or attributed to the funding recipient. And if the affiliate is not clearly identified with the recipient, the recipient has not "avoid[ed] saying anything inconsistent with [the] beliefs" it actually holds. The affiliate cannot express the recipient's belief if it is not identified as belonging to the recipient.

Moreover, even if there were some middle ground, it is not an adequate remedy to allow a recipient to limit its own speech through an affiliate. Rather than let its own message be distorted, an organization would have two options: decline federal funds, or accept funds and establish an affiliate, thereby forfeiting the ability to speak freely in its own name. But avoiding this kind of choice is the whole object of the doctrine of unconstitutional conditions.

## III

The Government contends that the Policy Requirement is necessary because the program aims to eradicate prostitution. But Congress did not legislatively mandate that organizations express support for the Government's policy. That measure was left to implementing officials.

[O]ur cases have long distinguished between conditions that define the limits of the Government program and those that aim to leverage funding to regulate speech outside the Government's own boundaries. The conditions on public employment at issue in cases like Perry v. Sindermann do not escape constitutional scrutiny because the conditional offer to avoid firing in exchange for silence on public matters has the form of an option.

The distinction we have drawn between mere subsidies and mandates that impact expression outside the Government program is no less important here.

As to that, we cannot improve upon what Justice Jackson wrote for the Court 70 years ago: "If there is any fixed star in our constitutional constellation, it is that no official, high or petty, can prescribe what shall be orthodox in politics, nationalism, religion, or other matters of opinion or force citizens to confess by word or act their faith therein." West Virginia Bd. of Ed. v. Barnette, 319 U.S. 624, 642 (1943).

The Policy Requirement compels as a condition of federal funding the affirmation of a belief that by its nature cannot be confined within the scope of the Government program. In so doing, it violates the First Amendment and cannot be sustained. The judgment of the Court of Appeals is affirmed.

It is so ordered.

---

JUSTICE SCALIA, with whom JUSTICE THOMAS joins, dissenting.

The Leadership Act provides that "any group or organization" that receives funds under the Act must have "a policy explicitly opposing prostitution and sex trafficking." ... The Act does not say that organizations that receive grants must espouse the Government's position as their own. It conditions the grant's receipt upon the adoption of an actual policy that explicitly opposes prostitution. That is not compelled speech. The mere conditioning of funds on "'the affirmation of a belief'" tied to the purpose of a government program involves "no compulsion at all." Such a condition is "the reasonable price of admission to a limited government-spending program that each organization remains free to accept or reject."

---

**EDITING NOTES:**
- Original word count: ~6,500 words
- Final word count: ~1,800 words
- Reduction: 72%
- Pedagogical goal: Preserve all discussions distinguishing Rust v. Sullivan and related unconstitutional conditions cases
- Sections removed: Detailed procedural history, lengthy discussion of program spending and alternative arguments, most dissent material
- Key preserved content:
  * Complete Rust v. Sullivan distinction (the critical difference between conditions on programs vs. conditions on recipients)
  * The analysis of why affiliate guidelines don't save the Policy Requirement
  * The leveraging discussion and distinction from Perry v. Sindermann
  * The core First Amendment principles about compelled speech
  * The Barnette quote
  * The conclusion that the condition "by its nature cannot be confined within the scope of the Government program"
- Cautions: Some of the Government's alternative arguments have been condensed; the dissent is substantially shortened to a key excerpt
