PERRY v. SINDERMANN
408 U.S. 593 (1972)

Mr. Justice STEWART delivered the opinion of the Court.

From 1959 to 1969 the respondent, Robert Sindermann, was a teacher in the state college system of the State of Texas. After teaching for two years at the University of Texas and for four years at San Antonio Junior College, he became a professor of Government and Social Science at Odessa Junior College in 1965. He was employed at the college for four successive years, under a series of one-year contracts. He was successful enough to be appointed, for a time, the cochairman of his department.

During the 1968-1969 academic year, however, controversy arose between the respondent and the college administration. The respondent was elected president of the Texas Junior College Teachers Association. In this capacity, he left his teaching duties on several occasions to testify before committees of the Texas Legislature, and he became involved in public disagreements with the policies of the college's Board of Regents. In particular, he aligned himself with a group advocating the elevation of the college to four-year status—a change opposed by the Regents. And, on one occasion, a newspaper advertisement appeared over his name that was highly critical of the Regents.

Finally, in May 1969, the respondent's one-year employment contract terminated and the Board of Regents voted not to offer him a new contract for the next academic year. The Regents issued a press release setting forth allegations of the respondent's insubordination. (The press release stated, for example, that the respondent had defied his superiors by attending legislative committee meetings when college officials had specifically refused to permit him to leave his classes for that purpose.) But they provided him no official statement of the reasons for the nonrenewal of his contract. And they allowed him no opportunity for a hearing to challenge the basis of the nonrenewal.

The respondent then brought this action in Federal District Court. He alleged primarily that the Regents' decision not to rehire him was based on his public criticism of the policies of the college administration and thus infringed his right to freedom of speech. He also alleged that their failure to provide him an opportunity for a hearing violated the Fourteenth Amendment's guarantee of procedural due process. The petitioners—members of the Board of Regents and the president of the college—denied that their decision was made in retaliation for the respondent's public criticism and argued that they had no obligation to provide a hearing. On the basis of these bare pleadings and three brief affidavits filed by the respondent, the District Court granted summary judgment for the petitioners. It concluded that the respondent had 'no cause of action against the (petitioners) since his contract of employment terminated May 31, 1969, and Odessa Junior College has not adopted the tenure system.'

The Court of Appeals reversed the judgment of the District Court. 430 F.2d 939 (5th Cir. 1970). First, it held that, despite the respondent's lack of tenure, the nonrenewal of his contract would violate the Fourteenth Amendment if it in fact was based on his protected free speech. Since the actual reason for the Regents' decision was 'in total dispute' in the pleadings, the court remanded the case for a full hearing on this contested issue of fact. Id. at 942-943. Second, the Court of Appeals held that, despite the respondent's lack of tenure, the failure to allow him an opportunity for a hearing would violate the constitutional guarantee of procedural due process if the respondent could show that he had an 'expectancy' of re-employment. It, therefore, ordered that this issue of fact also be aired upon remand. Id. at 943-944. We granted a writ of certiorari, 403 U.S. 917, and we have considered this case along with Board of Regents v. Roth, 408 U.S. 564 (1972).

I

The first question presented is whether the respondent's lack of a contractual or tenure right to re-employment, taken alone, defeats his claim that the nonrenewal of his contract violated the First and Fourteenth Amendments. We hold that it does not.

For at least a quarter-century, this Court has made clear that even though a person has no 'right' to a valuable governmental benefit and even though the government may deny him the benefit for any number of reasons, there are some reasons upon which the government may not rely. It may not deny a benefit to a person on a basis that infringes his constitutionally protected interests—especially, his interest in freedom of speech. For if the government could deny a benefit to a person because of his constitutionally protected speech or associations, his exercise of those freedoms would in effect be penalized and inhibited. This would allow the government to 'produce a result which (it) could not command directly.' Speiser v. Randall, 357 U.S. 513, 526 (1958). Such interference with constitutional rights is impermissible.

We have applied this general principle to denials of tax exemptions, unemployment benefits, and welfare payments. But, most often, we have applied the principle to denials of public employment. See, e.g., Shelton v. Tucker, 364 U.S. 479, 485-486 (1960); Keyishian v. Board of Regents, 385 U.S. 589, 605-606 (1967); Pickering v. Board of Education, 391 U.S. 563, 568 (1968). We have applied the principle regardless of the public employee's contractual or other claim to a job.

Thus, the respondent's lack of a contractual or tenure 'right' to re-employment for the 1969-1970 academic year is immaterial to his free speech claim. Indeed, twice before, this Court has specifically held that the nonrenewal of a nontenured public school teacher's one-year contract may not be predicated on his exercise of First and Fourteenth Amendment rights. Shelton v. Tucker, supra; Keyishian v. Board of Regents, supra. We reaffirm those holdings here.

In this case, of course, the respondent has yet to show that the decision not to renew his contract was, in fact, made in retaliation for his exercise of the constitutional right of free speech. The District Court foreclosed any opportunity to make this showing when it granted summary judgment. Hence, we cannot now hold that the Board of Regents' action was invalid.

But we agree with the Court of Appeals that there is a genuine dispute as to 'whether the college refused to renew the teaching contract on an impermissible basis—as a reprisal for the exercise of constitutionally protected rights.' 430 F.2d 939, 943 (5th Cir. 1970). The respondent has alleged that his nonretention was based on his testimony before legislative committees and his other public statements critical of the Regents' policies. And he has alleged that this public criticism was within the First and Fourteenth Amendments' protection of freedom of speech. Plainly, these allegations present a bona fide constitutional claim. For this Court has held that a teacher's public criticism of his superiors on matters of public concern may be constitutionally protected and may, therefore, be an impermissible basis for termination of his employment. Pickering v. Board of Education, supra.

For this reason we hold that the grant of summary judgment against the respondent, without full exploration of this issue, was improper.

II

The respondent's lack of formal contractual or tenure security in continued employment at Odessa Junior College, though irrelevant to his free speech claim, is highly relevant to his procedural due process claim. But it may not be entirely dispositive.

We have held today in Board of Regents v. Roth, 408 U.S. 564 (1972), that the Constitution does not require opportunity for a hearing before the nonrenewal of a nontenured teacher's contract, unless he can show that the decision not to rehire him somehow deprived him of an interest in 'liberty' or that he had a 'property' interest in continued employment, despite the lack of tenure or a formal contract. In Roth the teacher had not made a showing on either point to justify summary judgment in his favor.

Similarly, the respondent here has yet to show that he has been deprived of an interest that could invoke procedural due process protection. As in Roth, the mere showing that he was not rehired in one particular job, without more, did not amount to a showing of a loss of liberty. Nor did it amount to a showing of a loss of property.

But the respondent's allegations—which we must construe most favorably to the respondent at this stage of the litigation—do raise a genuine issue as to his interest in continued employment at Odessa Junior College. He alleged that this interest, though not secured by a formal contractual tenure provision, was secured by a no less binding understanding fostered by the college administration. In particular, the respondent alleged that the college had a de facto tenure program, and that he had tenure under that program. He claimed that he and others legitimately relied upon an unusual provision that had been in the college's official Faculty Guide for many years:

'Teacher Tenure: Odessa College has no tenure system. The Administration of the College wishes the faculty member to feel that he has permanent tenure as long as his teaching services are satisfactory and as long as he displays a cooperative attitude toward his co-workers and his superiors, and as long as he is happy in his work.'

Moreover, the respondent claimed legitimate reliance upon guidelines promulgated by the Coordinating Board of the Texas College and University System. These guidelines, adopted as 'Policy Paper 1,' provided that the probationary period for a faculty member "shall not exceed seven years, including within this period appropriate full-time service in all institutions of higher education," and that adequate cause must be shown for dismissal of a tenured faculty member. The respondent alleged that, because he had been employed as a professor within the Texas system for 10 years, he should have 'tenure' under these provisions. Thus, the respondent offered to prove that a teacher with his long period of service at this particular State College had no less a 'property' interest in continued employment than a formally tenured teacher at other colleges, and had no less a procedural due process right to a statement of reasons and a hearing before college officials upon their decision not to retain him.

We have made clear in Roth, supra, at 577, that 'property' interests subject to procedural due process protection are not limited by a few rigid, technical forms. Rather, 'property' denotes a broad range of interests that are secured by 'existing rules or understandings.' Id., at 577. A person's interest in a benefit is a 'property' interest for due process purposes if there are such rules or mutually explicit understandings that support his claim of entitlement to the benefit and that he may invoke at a hearing. Ibid.

A written contract with an explicit tenure provision clearly is evidence of a formal understanding that supports a teacher's claim of entitlement to continued employment unless sufficient 'cause' is shown. Yet absence of such an explicit contractual provision may not always foreclose the possibility that a teacher has a 'property' interest in reemployment. The law of contracts long has employed a process by which agreements, though not formalized in writing, may be 'implied' from the promisor's words and conduct in light of the surrounding circumstances.

A teacher, like the respondent, who has held his position for a number of years, might be able to show from the circumstances of this service—and from other relevant facts—that he has a legitimate claim of entitlement to job tenure. Just as this Court has found there to be a 'common law of a particular industry or of a particular plant' that may supplement a collective-bargaining agreement, United Steelworkers v. Warrior & Gulf Nav. Co., 363 U.S. 574, 579 (1960), so there may be an unwritten 'common law' in a particular university that certain employees shall have the equivalent of tenure. This is particularly likely in a college or university, like Odessa Junior College, that has no explicit tenure system even for senior members of its faculty, but that nonetheless may have created such a system in practice.

We do not now hold that the respondent has any such legitimate claim of entitlement to job tenure. For '(p)roperty interests . . . are not created by the Constitution. Rather, they are created and their dimensions are defined by existing rules or understandings that stem from an independent source such as state law . . ..' Board of Regents v. Roth, supra, 408 U.S., at 577. If it is the law of Texas that a teacher in the respondent's position has no contractual or other claim to job tenure, the respondent's claim would be defeated.

In this case, the respondent has alleged the existence of rules and understandings, promulgated and fostered by state officials, that may justify his legitimate claim of entitlement to continued employment absent 'sufficient cause.' We disagree with the Court of Appeals insofar as it held that a mere subjective 'expectancy' is protected by procedural due process, but we agree that the respondent must be given an opportunity to prove the legitimacy of his claim of such entitlement in light of 'the policies and practices of the institution.' 430 F.2d, at 943. Proof of such a property interest would not, of course, entitle him to reinstatement. But such proof would obligate college officials to grant a hearing at his request, where he could be informed of the grounds for his nonretention and challenge their sufficiency.

Therefore, while we do not wholly agree with the opinion of the Court of Appeals, its judgment remanding this case to the District Court is affirmed.

Affirmed.

Mr. Justice POWELL took no part in the decision of this case.

Mr. Chief Justice BURGER, concurring.

I concur in the Court's judgments and opinions in Perry and Sindermann but there is one central point in both decisions that I would like to underscore since it may have been obscured in the comprehensive discussion of the cases. That point is that the relationship between a state institution and one of its teachers is essentially a matter of state concern and state law. The Court holds today only that a state-employed teacher who has a right to re-employment under state law, arising from either an express or implied contract, has, in turn, a right guaranteed by the Fourteenth Amendment to some form of prior administrative or academic hearing on the cause for nonrenewal of his contract. Thus, whether a particular teacher in a particular context has any right to such administrative hearing hinges on a question of state law. The Court's opinion makes this point very sharply:

'Property interests . . . are created and their dimensions are defined by existing rules or understandings that stem from an independent source such as state law . . ..' Board of Regents v. Roth, 408 U.S. 564, at 577 (1972).

[Justice Brennan's and Justice Marshall's partial dissents omitted.]

---

EDITING NOTES:
- Original word count: approximately 5,200 words (majority opinion only)
- Final word count: approximately 2,000 words
- Reduction: approximately 62%
- Pedagogical goal: To teach the unconstitutional conditions doctrine—the principle that government cannot condition a benefit on the surrender of constitutional rights, while also introducing property interests in government employment
- Sections removed: 
  * Syllabus
  * Most string citations (retained key cases only)
  * Detailed procedural history
  * Extended quotations from Policy Paper (retained essential content)
  * Extensive contract law citations from Corbin treatise
  * Justice Brennan's and Justice Marshall's partial dissents
- Sections retained:
  * Core unconstitutional conditions principle from Part I with the Speiser v. Randall quote
  * Part II on procedural due process and property interests (because it demonstrates that the unconstitutional conditions principle operates independently of whether a property interest exists)
  * Chief Justice Burger's concurrence (emphasizes state law foundation of property interests)
- Cautions: 
  * Part I teaches the unconstitutional conditions doctrine; Part II teaches property interests. Both are important but Part I is the primary focus for unconstitutional conditions units.
  * The case demonstrates that even without a property right, government cannot condition a benefit on surrender of First Amendment rights.
  * If teaching in a shorter unit, Part II could be further condensed to a brief summary.